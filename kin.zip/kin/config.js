require("./database/module")

//GLOBAL PAYMENT
global.storename = "*K̷̪̟͓̞̗̥̜̦̦̣͖͎͇̎̈̊̍̊͛̐̑̐ͅi̷͍͈̒̈́͐̽n̴̲͈͕̮̰̰̤̦̙̜̈͌̏̈́̓͛̚͜c̴̢͖̭̤̾̉̈́̋h̸̡̧̗̙̱̙̭̼̭̆̑͒̓͝a̸̡̛̩̙̟̳̬͇̖͔̺̫̜͔̼͋̾̄̕͜ņ̸̨̥̣̙̩̘͌̒̀͑̓̄̃̀̂͌͋̚*"
global.dana = "085389296108"
global.qris = "https://a.top4top.io/"


// GLOBAL SETTING
global.owner = "6285389296108"
global.namabot = "*K̷̪̟͓̞̗̥̜̦̦̣͖͎͇̎̈̊̍̊͛̐̑̐ͅi̷͍͈̒̈́͐̽n̴̲͈͕̮̰̰̤̦̙̜̈͌̏̈́̓͛̚͜c̴̢͖̭̤̾̉̈́̋h̸̡̧̗̙̱̙̭̼̭̆̑͒̓͝a̸̡̛̩̙̟̳̬͇̖͔̺̫̜͔̼͋̾̄̕͜ņ̸̨̥̣̙̩̘͌̒̀͑̓̄̃̀̂͌͋̚*"
global.nomorbot = "6285389296108"
global.namaCreator = "*Z̴y̴n̷*"
global.linkyt = "https://youtube.com/"
global.autoJoin = false
global.antilink = false
global.versisc = '1̥̭͎̖̈̿̐͋̀̓̆̈́̈͗̉̇͊̍̿͊2̫̲̩̤̰̏̄̂̋̈͛̀̒ͅ.̲͍̱̯̰̃̊̈́͌͋͑̓̈́́́̈́̄̏͆͗0̲̮̠͎̜̣̬̮͓̪̫̞̽͆̓͛̉̃̀̏̔͆͊̚̚.̥͕̭̬̫̠̰͙̙̪̠̪͐̓͛͑͂̇̇0̤̫̜̖̟͉̟̠̫͙͕͓̠̭͈̒̈̃͌͆̋̋̐ͅ'

// DELAY JPM
global.delayjpm = 9500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com/'
global.eggsnya = '15'
global.location = '1'



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://g.top4top.io/'
global.isLink = 'https://whatsapp.com/channel/'
global.packname = "K̷̪̟͓̞̗̥̜̦̦̣͖͎͇̎̈̊̍̊͛̐̑̐ͅi̷͍͈̒̈́͐̽n̴̲͈͕̮̰̰̤̦̙̜̈͌̏̈́̓͛̚͜c̴̢͖̭̤̾̉̈́̋h̸̡̧̗̙̱̙̭̼̭̆̑͒̓͝a̸̡̛̩̙̟̳̬͇̖͔̺̫̜͔̼͋̾̄̕͜ņ̸̨̥̣̙̩̘͌̒̀͑̓̄̃̀̂͌͋̚"
global.author = "Z̴y̴n̷"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})