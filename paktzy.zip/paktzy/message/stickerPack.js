const fs = require('fs')


exports.spam2 = fs.readFileSync('./media/stickernye/jangan spam.webp')
exports.istigfar = fs.readFileSync('./media/stickernye/istigfar.webp')
exports.hanyaadmin = fs.readFileSync('./media/stickernye/hanya admin.webp')
exports.jadiinadmin = fs.readFileSync('./media/stickernye/jadiin admin.webp')
exports.ucapsalam = fs.readFileSync('./media/stickernye/ucapsalam.webp')
exports.samasama = fs.readFileSync('./media/stickernye/sama sama.webp')
exports.kumsalam = fs.readFileSync('./media/stickernye/salam.webp')
exports.spam1 = fs.readFileSync('./media/stickernye/oke tunggu.webp')
exports.khususowner = fs.readFileSync('./media/stickernye/owner.webp')
exports.katakasar = fs.readFileSync('./media/stickernye/toxic.webp')