/*

Disini adalah data tempat untuk Voice Note milik si Nina


*/

//untuk user saat ada yg bilang botz
exports.botz =[
"./media/audionye/bot/ada apa kak.mp3",
"./media/audionye/bot/ada apa kak1.mp3",
"./media/audionye/bot/iya kak.mp3",
"./media/audionye/bot/kenapa kak.mp3",
"./media/audionye/bot/oy.mp3"
]


//untuk unregister command
exports.unregister =[
"./media/audionye/unregister/ara ara goblok.mp3",
"./media/audionye/unregister/ga boleh.mp3",
"./media/audionye/unregister/ga da.mp3",
"./media/audionye/unregister/ga mau.mp3",
"./media/audionye/unregister/gambare.mp3",
"./media/audionye/unregister/goblok.mp3",
"./media/audionye/unregister/kaga ada.mp3",
"./media/audionye/unregister/baka.mp3",
"./media/audionye/unregister/ngomong apaan sih.mp3"
]

//untuk banned user
exports.enggakmau =[
"./media/audionye/unregister/ga boleh.mp3",
"./media/audionye/unregister/ga mau.mp3",
"./media/audionye/unregister/lu siapa anjir.mp3",
]


//untuk user saat ada yg bilang halo
exports.ucaphai =[
"./media/audionye/waktu/moshi moshi.mp3",
"./media/audionye/waktu/moshi mossh.mp3"
]

//untuk user saat ada yg bilang selamat malam
exports.ucapmalam =[
"./media/audionye/waktu/oyasumi.mp3",
"./media/audionye/waktu/oyasuminasai.mp3"
]


//untuk user saat ada yg bilang selamat siang
exports.ucapsiang =[
"./media/audionye/waktu/konichiwa.mp3",
]

//untuk user saat ada yg bilang selamat pagi
exports.ucappagi =[
"./media/audionye/waktu/asautegondalimas.mp3",
"./media/audionye/waktu/ohayo.mp3",
"./media/audionye/waktu/ohayoghosaimase.mp3",
]

//untuk user saat ada yang Toxic
exports.toxicbro =[
"./media/audionye/toxic/dosa pantek.mp3",
"./media/audionye/toxic/heeh.mp3",
"./media/audionye/toxic/jangan toxic om.mp3"
]


//untuk user saat ada yang Sange
exports.sangebro = [
"./media/audionye/toxic/dosa pantek.mp3"
]

//untuk user saat ada yg spam
exports.spamnih =[
"./media/audionye/spam/jangan spam ntar gua ewe.mp3"
]

//untuk user saat ada yg bilang i love u
exports.loplop =[
"./media/audionye/lop you too kambing.mp3",
"./media/audionye/lopyoutoo.mp3"
]

//untuk user yang ucap asalamualaikum
exports.ucapsalamikum =[
"./media/audionye/walaikunsalam.mp3"
]


























