exports.teksbanned =["Kaka telah di banned","Maaf kamu sudah di banned","Yahaha udah kena banned mau akses fitur","Mboh karepmu"]

exports.tekscmd =["Command tidak ditemukan","Maaf kak command tidak di temukan","Gak ada","Command tidak tersedia",
"Apaan tuh ? 🙄",
"Maap kak ga ada dalam menu ☹️",
"Yang bener atuh kak ketiknya 🙄",
"Yang bener nulisnya bambang 🤨",
"Engga ada kak 🙃",
"Auah kaka bau","Salah ketik itu kak 😮",
"Kaka ngetik apasih aku ga ngerti 🥺","Oke kak aku proses yah, proses gundulmu ga ada itu dalam menu 😒",
"Ngetiknya yang bener dong 😠",
"Enggak mau 🙁","Enggak ah","Berantem yuk 😤","Berantem yuk maju sini 😠","Aku ga mau jawab 😤",
"Hmm apa yah ga tau aku 🤤",
"Ga tau aku kan ikan 😎","😚",
"Hadehh 😑","Maap kaka yang ganteng aku ga tau 🥺","Maap kaka yang cantik aku ga tau 🥺",
"Muke lu ke gorengan 🤤","Enggak ketemu kak 🥺",
"Yo ndak tau kok tanya saya 😅",
"Macam tak betul budak ni 😑",
"Ih apasih ga jelas banget kek admin, hehe camda 😅",
"Waduh apaan tuh kak 🙄","Sedang di proses silakan tunggu 3 jam lagi",
"Gak ada 🙂","Mana saya tau, sayakan ga tau 🙁","Berhenti jangan mainin aku kak 😥",
"Waduh klo itu saya tidak bisa 😳","ERROR 😎"]


exports.bagai = ['Kita Kenal?', 'Nanya Terus deh', 'Tidak Tahu', 'Gua tabok boleh ?', 'Cari Aja Sendiri', 'Kurang Tahu', 'Mana Saya Tahu, Saya kan ikan', 'Hah kamu tanya sama aku trus aku tanya ke siapa dong', 'Whahahaha ga tau 😑']


exports.cek1 = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']

exports.wa = ['Penyayang', 'Pemurah', 'Pemarah', 'Pemaaf', 'Penurut', 'Baik', 'Baperan', 'Baik Hati', 'penyabar', 'UwU', 'top deh, pokoknya', 'Suka Membantu']


exports.apa = [
'iya dong jelas itu',
'Tidak lah',
'Oh tentu saja tidak',
'Ya mana saya tau kok tanya saya',
'Rahasia dong',
'ga usah di tanya emang udah kaya gitu dia',
'Au ah mending mandi',
'Bentar aku lagi berak',
'Knpa emang kamu suka sama dia yak ??',
'Haha mna mungkin 🤣',
]


exports.teksspam =["Jangan spam om",
"Jangan spam",
"Jangan spam ya",
"Woy jangan spam",
"Ups kamu terdeteksi spam, tolong beri jeda 5 detik"]


exports.hob = [
'Memasak',
'Membantu Atok',
'Mabar',
'Nobar',
'Sosmedtan',
'Membantu Orang lain',
'Nonton Anime',
'Nonton Drakor',
'Naik Motor',
'Nyanyi',
'Menari',
'Bertumbuk',
'Menggambar',
'Foto fotoan Ga jelas',
'Maen Game',
'Berbicara Sendiri',
]


exports.dare = [
'Kirim pesan ke mantan kamu dan bilang "aku masih suka sama kamu',
'telfon crush/pacar sekarang dan ss ke pemain',
'pap ke salah satu anggota grup',
'Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo',
'ss recent call whatsapp',
'drop emot 🤥 setiap ngetik di gc/pc selama 1 hari',
'kirim voice note bilang can i call u baby?',
'drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu',
'pake foto sule sampe 3 hari',
'ketik pake bahasa daerah 24 jam',
'ganti nama menjadi "gue anak lucinta luna" selama 5 jam',
'chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you',
'prank chat mantan dan bilang " i love u, pgn balikan',
'record voice baca surah al-kautsar',
'bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini',
'sebutkan tipe pacar mu!',
'snap/post foto pacar/crush',
'teriak gajelas lalu kirim pake vn kesini',
'pap mukamu lalu kirim ke salah satu temanmu',
'kirim fotomu dengan caption, aku anak pungut',
'teriak pake kata kasar sambil vn trus kirim kesini',
'teriak " anjimm gabutt anjimmm " di depan rumah mu',
'ganti nama jadi " BOWO " selama 24 jam',
'Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll',
]


exports.ilhamberkata =['Lebih baik mengerti sedikit daripada salah mengerti.',
'Hampir semua pria memang mampu bertahan menghadapi kesulitan. Namun, jika Anda ingin menguji karakter sejati pria, beri dia kekuasaan.',
'Bila tekad seseorang kuat dan teguh, Tuhan akan bergabung dalam usahanya.',
'Penderitaan adalah pelajaran.',
'Ilmu pengetahuan tanpa agama adalah pincang.',
'Hidup itu seperti sebuah sepeda, agar tetap seimbang kita harus tetap bergerak.',
'Perbedaan masa lalu, sekarang, dan masa depan tak lebih dari ilusi yang keras kepala.',
'Sebuah meja, sebuah kursi, semangkuk buah, dan sebuah biola; apa lagi yang dibutuhkan agar seseorang bisa merasa bahagia?',
'Belas kasihanlah terhadap sesama, bersikap keraslah terhadap diri sendiri.',
'Cara paling baik untuk menggerakkan diri Anda ialah memberi tugas kepada diri sendiri.',
'Kita tidak boleh kehilangan semangat. Semangat adalah stimulan terkuat untuk mencintai, berkreasi dan berkeinginan untuk hidup lebih lama.',
'Manusia akan bahagia selama ia memilih untuk bahagia.','Saya tidak berharap menjadi segalanya bagi setiap orang. Saya hanya ingin menjadi sesuatu untuk seseorang.',
'Apabila sempurna akal seseorang, maka sedikit perkataannya.','Bahagialah orang yang dapat menjadi tuan untuk dirinya, menjadi kusir untuk nafsunya dan menjadi kapten untuk bahtera hidupnya.',
'Sahabat yang jujur lebih besar harganya daripada harta benda yang diwarisi dari nenek moyang.','Yang paling melelahkan dalam hidup adalah menjadi orang yang tidak tulus.',
'Terbuka untuk Anda, begitulah Tuhan memberi kita jalan untuk berusaha. Jangan pernah berfikir jalan sudah tertutup.',
'Penundaan adalah kuburan dimana peluang dikuburkan.','Cinta bukan saling menatap mata, namun melihat ke arah yang sama bersama-sama.',
'Kita adalah apa yang kita kerjakan berulang kali. Dengan demikian, kecemerlangan bukan tindakan, tetapi kebiasaan.',
'Jangan pernah mencoba menjadikan putra atau putri Anda menjadi seperti Anda. Diri Anda hanya cukup satu saja.',
'Jika Anda bisa membuat orang lain tertawa, maka Anda akan mendapatkan semua cinta yang Anda inginkan.',
'Masalah akan datang cepat atau lambat. Jika masalah datang, sambut dengan sebaik mungkin. Semakin ramah Anda menyapanya, semakin cepat ia pergi.',
'Kita tak bisa melakukan apapun untuk mengubah masa lalu. Tapi apapun yang kita lakukan bisa mengubah masa depan.',
'Kesabaran adalah teman dari kebijaksanaan.','Orang-orang kreatif termotivasi oleh keinginan untuk maju, bukan oleh keinginan untuk mengalahkan orang lain.',
'Dimanapun engkau berada selalulah menjadi yang terbaik dan berikan yang terbaik dari yang bisa kita berikan.',
'Kebencian seperti halnya cinta, berkobar karena hal-hal kecil.',
'Anda tidak perlu harus berhasil pada kali pertama.',
'Satu jam yang intensif, jauh lebih baik dan menguntungkan daripada bertahun-tahun bermimpi dan merenung-renung.',
'Hal terbaik yang bisa Anda lakukan untuk orang lain bukanlah membagikan kekayaan Anda, tetapi membantu dia untuk memiliki kekayaannya sendiri.',
'Tidak ada jaminan keberhasilan, tetapi tidak berusaha adalah jaminan kegagalan.',
'Aku tidak tahu kunci sukses itu apa, tapi kunci menuju kegagalan adalah mencoba membuat semua orang senang.']




exports.ngebucin =[
"Kalau aku jadi wakil rakyat aku pasti gagal, gimana mau mikirin rakyat kalau yang selalu ada dipikiran aku hanyalah dirimu.",
"Disaat hati sudah ditakdirkan untuk memilihmu, plis jangan pergi ya aku mohon.. Kalo kamu masih mau pergi ya udah aku nitip makan :))",
"Kolak pisang Tahu sumedang, walau jarak membentang cintaku takkan pernah hilang..",
"Ketika kamu telah membuatnya bahagia dan dia masih memilih orang lain, yakinlah..mungkin kamu belum kaya!",
"Kalau jelangkungnya kaya kamu, dateng aku jemput, pulang aku anter deh.",
"Makan apapun aku suka asal sama kamu, termasuk makan ati.",
"Aku suka kamu, kamu suka dia, dia suka sama orang lain :v",
"Kamu seperti pensi warna deh, bisa mewarnai hari-hariku…",
"Kalo kamu bidadari, akan kupatahkan semua sayapmu. Karena aku gak rela kamu kembali ke surga..",
"aku punya sejuta alasan melupakanmu, tapi tak ada yang bisa memaksaku berhenti mencintaimu",
"Aneh rasanya.. bagaimana dengan hanya mendengar namamu saja, hatiku bisa tersayat teriris ngilu seperti luka basah yang tersiram cuka??",
"Dia selalu berhasil membuatku terluka, tetapi aku slalu gagal membencinya..",
"Ada 3 hal yang tidak bisa dihitung di dunia ini :\n1.jumlah bintang dilangit\n2.jumlah ikan dilaut\n3.jumlah cintaku padamu…",
"Kalau aku udah sayang sama kamu, hujan badai pun aku otw apelin kamu..",
"Aku bertahan meski kau sakiti. Agar kau mengerti sakit tidak berarti untuk cintaku yang tulus ini..",
"Tau gak hal yang lebih lucu dari badut? Waktu kamu marah..\nTau gak yang menyenangkan daripada mendapat hadiah? Melihatmu tersenyum..",
"Jaga mereka yg menyayangimu secara ekstrem.\nBukan yg sekedar..\nBukan yg kebetulan..\nApalagi pelampiasan..",
"Sering sih dibikin makan ati. Tapi menyadari kamu masih di sini bikin bahagia lagi.",
"Cobalah untuk menghargai orang yang sudah sabar menghadapi sifatmu. Karena dia percaya suatu saat nanti kamu bisa berubah berkat dia yang udah tulus dan ikhlas bersabar.",
"Cinta itu gak mudah hilang, apalagi berubah-ubah tempat.\nJadi kalau doi move on-nya cepet, mungkin emang dia gak cinta.",
"Baca juga: Kumpulan Kata-kata (Quotes) Aesthetic Bahasa Indonesia",
"singkat saja, aku rindu :)",
"Cukup jaringan aja yang hilang, kamu jangan..",
"Musuhku adalah mereka yang ingin memilikimu juga",
"Meskipun kamu marah, aku tetep sayang kamu kok…",
"Jam tidurku hancur dirusak rindu..",
"Cuma satu keinginanku, dicintai olehmu..",
"Fokus ke kamu aja, gak mau ke yang lain.",
"Berjanjilah untuk terus bersamaku sekarang, esok dan selamanya..",
"Banyak yang selalu ada, tapi kalo cuma kamu yang aku mau, gimana?",
"Yang penting itu kebahagiaan kamu, aku sih gak penting..",
"Aku lebih baik mempunyai separuh hatimu daripada seluruh hati milik orang lain",
"kamu, satu kata berjuta penderitaan",     
"Terkadang aku iri sama layangan..talinya putus saja masih dikejar kejar dan gak rela direbut orang lain..",
"Kamu adalah patah hati terbaik yang tak akan pernah aku sesali..",
"Semenjak aku berhenti berharap pada dirimu, aku jadi tidak semangat dalam segala hal..",
"Cinta bermula dari mata, jadi tidak heran jika cinta pun berakhir dengan air mata..",
"Kisah cinta orang lain kayak es krim paddle pop rainbow, kisah cintaku kayak es batu, tawar dingin dan keras..",
"Aku memang akan terlihat bodoh ketika mencintai kamu, tapi aku akan lebih bodoh ketika tidak pernah mencintai kamu..",
"Mengejar itu capek, tapi lebih capek lagi menunggu\nMenunggu kamu menyadari keberadaanku..",
"Cukup salju yang beku, jangan hatimu..\nCukup cuaca yang dingin, jangan sikapmu..",
"Silahkan pergi kemana kau suka, tapi jangan lupa kalo udah dapet yang baru kabarin aku ya..",
"Harga hati 2 milliar lebih, aku kasih ke kamu gratis, malah kamu sia-siakan..",
"Aku gak sedih besok hari senin, aku sedihnya kalau besok gak bisa ketemu kamu..",
"Sejak mengenal dirimu, aku jadi tau sesaknya rindu..",
"Orang yang cerewet, bawel, pecicilan dan gak bisa diem adalah orang yang sangat dirindukan pas gak ada..",
"Dari jauh warna “ungu”\nDari dekat warna “biru”\nDari jauh aku “rindu”\nDari dekat aku “malu”\nDari mulut “I love you”\nDari hati “I miss you” ",
"Aku ingin jadi mimpi indah dalam tidurmu, dimana aku ingin jadi suatu yang akan kamu rindukan..\nKarena aku selalu rapuh tanpa adanya dirimu..",
"Dalam lelapku akan selalu terbayang wajahmu, dalam tatapku akan jelas terlihat bagaimana kita bertemu, dan dalam anganku akan selalu terucap kata rindu..",
"Hanya dengan hitungan jam kita akan bertemu lagi, tapi rasanya sangat lama bagaikan satu dekade. Tak terbayang seberapa girangnya hati ini berada dalam pelukanmu..",
"Untuk cintaku di sana, jangan pernah berfikir aku akan meninggalkan kamu. Karena cinta, kasih sayang dan rindu ini hanya padamu..",
"Setiap hari, jam, menit, detik, aku akan selalu memikirkanmu dan tidak ada kondisi tanpa aku rindu padamu..",
"Di jiwa yang santuy terdapat kebucinan yang mendarah daging.. Hahahaha….",
"Agama sudah melarang kita pacaran, eh tetep aja pacaran. Giliran diputusin bilangnya, “cobaan apa ini ya Allah’. Cobaan dengkulmu!",
"Doa hari senin: Bismillah semoga cepet malem minggu wkwkwk",
"Jika kamu mencintainya kejar dia mumpung lampu hijau, kalo udah lampu merah trobos aja terus kan kebiasaan orang +62",
"Aku lebih suka apel daripada anggur, soalnya aku lebih suka ngapelin kamu daripada nganggurin kamu",
"Aku itu kayak kipas angin, Meski tengok kanan tengok kiri, tapi tetap ada ditempat yang sama. Tetep sama kamu, tetep mencintai kamu",
"Kamu tau gak, kenapa kalo belajar menghafal aku selalu melihat keatas? Soalnya kalo merem langsung kebayang wajah kamu 🙂",
"Aku adalah murid teladan, karena setiap hari aku selalu belajar, belajar mencintaimu sepenuh hati",
"Apa aku harus ganti nama jadi “untung” agar kamu gak nolak aku lagi?",
"Sudut yang istimewa selain sin dan cos adalah… Kangen :v",
"jomblo itu banyak temennya, tiap nembak selalu dijawab kita temenan aja.",
"Orang yang punya pacar itu harus sabar dengan pasangan yang dimilikinya. Apa lagi yang gak punya..",
"Bukannya tak pantas buat ditunggu, hanya saja sering memberi harapan palsu",
"Aku hanya penikmat senyumanmu, bukan pemilik, apalagi penyebab..",
"Semoga jodohku malam ini rebahan dikamar aja, gak kemana-mana, gak apel-apelan. Tolong ya yang jadi pacarnya sekarang jangan sentuh-sentuh dia!",
"Sakit batuk: es teruss…\nSakit mata: mantengin hape teruss..\nSakit hati: ngarepin dia teruss..",
"Mimpi ketemu kamu aja sudah seneng banget, apalagi ketemu beneran…",
"Minggu kali ini masih sama, kamu masih milik orang lain sementara aku masih dengan harapan yang sama : memilikimu..",
"Cinta tapi tak dianggap itu seperti sakit tapi tak berdarah..",
"Salahkah ku mencintaimu\nPunya rasa rindu padamu\nMeski ku tahu ku tak mungkin bisa memilikimu",
"Dear pasangan bucin sedunia, ujung dari hubungan kalian sama, menikah atau berpisah",
"Anggaplah aku rumahmu, jika kamu pergi kamu mengerti kemana arah pulang. Menetaplah bila kamu mau dan pergilah jika kamu bosan..",
"Entah mengapa tiap melihat kamu, aku keingat akan ujian. Susah sih, tetapi tetap saja harus diperjuangkan demi masa depan..",
"Aku baru sadar, ternyata bersikap bodo amat itu lebih menyenangkan daripada peduli tapi tidak dihargai..",
"Aku gak mau kamu pergi kemana-mana. Kalau pergi kerja gak papa, soalnya kalau kamu nggak kerja aku juga nggak glowing.",
"Hal yang terbaik dalam mencintai seseorang adalah dengan diam-diam mendo’akannya.",
"Tenang wae neng, ari cinta Akang mah sapertos tembang krispatih; Tak lekang oleh waktu.",
"Demi cinta kita menipu diri sendiri. Berusaha kuat nyatanya jatuh secara tak terhormat.",
"Kau tak patut berharap kepada manusia, karena akan berujung sia. Berharaplah kepada Penciptanya, niscaya Dia akan membalikkan hati umatnya untukmu..",
"Kau suka pada seseorang. Kau berharap besar pada orang itu. Orang itu tidak seperti yang kau kira. Kau marah-marah dan merasa dikecewakan. Coba tengok lagi, apakah dia atau harapanmu sendiri yang menghancurkanmu?",                     
"Hidup hanya sekali berhenti buang waktumu dengan mencintai orang yang tidak pernah mencintaimu ..",
"Cintailah sesuatu itu sekadar saja, berkemungkinan ia akan menjadi kebencianmu pada suatu ketika, bencilah yang engkau benci itu sekadar saja, berkemungkinan ia akan menjadi kecintaanmu pada satu ketika..",
"maaf bapak ibu guru sing tak jawab A, B, C amargo D, E wis karo liyane",
"Tresno iki kadang koyo criping telo, iso ajur nek ora ngati ati le nggowo",
"Nek kowe dikon milih de’e utowo aku, miliho de’e wae. Aku dudu pilihan. Mergo nek sing tenanan cinta kuwi ra bakal ninggal.",
"Adam & Hawa, Romeo & Juliet. Terus aku karo sopo?",
"Tapi yo enek sih seng dilarani, diselingkuhi, dikhianati, tapi iseh bertahan. Dudu mergo sayang tapi wedi karo seng jenenge “suwung” ",
"Pantesan aku gering, jebule sing tak pangan harapan palsu.",
"Dudu cinta nek ora cemburu. Tapi dudu cinta barang nek terus nglarani.",
"Aku sayang kowe, opo aku kudu ngode terus? Kapan pekamu?",
"Cinta dudu perkara sepiro kerepe kowe ngucapke, tapi sepiro akehe seng mbok buktike",
"Dadi kowe penak ya, pinter nggawe wong sayang banget neng kowe, trus mbok tinggal karo sing liyo pas lagi sayang-sayange.",
"Isih tetep bertahan karo wong sing isone mung ngelarani kowe? Kuwi jenenge sayang? Opo ora iso golek sing luwih seko kuwi?"
]

exports.katahai =["Halo","halo","Hallo","hallo","Hai","hai","Moshi moshi","moshi moshi","Kirara","kirara"]

exports.katamalem =[
"Selamat malam","selamat malam","Malam","malam","Malem","malem","oyasumi","Oyasumi",
"Oyasuminasai","oyasuminasai","Night","night","Good night","good night","Selamat tidur","selamat tidur"
]

exports.katasiang =[
"Selamat siang","selamat siang","Siang","siang","koniciwa","Koniciwa"
]


exports.katasore =[
"Selamat sore","selamat sore","Sore","sore"
]


exports.katalopyou =[
"I love u","i love u","Love u","love u","Love u kirara"
]

exports.tekssalah =[
"Salah","Bukan","Salah salah salah","Sualah",
"Selamat jawaban kamu salah","Coba lagi",
"Hampir","Dikit lagi","Bukan bukan","Yah salah",
"Yahaha salah","Bukan itu","No!",
"Horeeeee!\nEh salah bukan itu","Asik salah",
"Masih salah 😎","Bukan itu bambang"
]

exports.badud =["kirara","Kirara","bot","Bot"]

exports.ohayo =["pagi",
"Pagi",
"ohayo",
"Ohayo"
]

exports.bapak = [
'Wah Mantap Lu Masih Punya Bapack\nPasti Bapack Nya Kuli :v\nAwowkwokwwok\n#CandabOs',
'Aowkwwo Disini Ada Yteam :v\nLu Yteam Bro? Awowkwowk\nSabar Bro Ga Punya Bapack\n#Camda',
'Bjir Bapack Mu Ternyata Sudah Cemrai\nSedih Bro Gua Liatnya\nTapi Nih Tapi :v\nTetep Ae Lu Yteam Aowkwowkw Ngakak :v',
'Jangan #cekbapak Mulu Broo :v\nKasian Yang Yteam\nNtar Tersinggung Kan\nYahahaha Hayyuk By : Ramlan ID',
]


exports.anime =[
"uzumaki naruto","uchiha sasuke","haruno sakura","hyuga neji","kiba","hinata","tenten","uchiha shisui","uchiha itachi","kisame","uchiha obito","hatake kakashi","uzumaki karin","zetsu","uchiha madara","tobirama","jiraiya","tsunade","killer bee","nara shikamaru","ino","choji","nagato","konan","itachi","gara","kankuro","temari",
"tanjiro","giyu","akaza","kyojuro","nezuko","inosuke","zenitsu","sabito","gyomei","shinobu","kanao","mitsuri","aoi kanzaki","tengen","muichiro","genya","muzan","sanemi",
"esdeath","tatsumi","akame","kurome","najenda","leone","sheele",
"ichigo","kanpachi","aizen","kuruyashiki","urahara kisuke","yoruichi",
"kirito","asuna","sinon",
"luffy","zoro","nami","robin","sanji","usop","chopper",
"goku","vegeta","gohan","beerus","bulma","goten","krillin","piccolo",
"saitama","genos",
"rimuru","milim nava","benimaru","souei","shion",
"kazuma sato","megumin",
"chizuru ichinose","kazuya kinoshita","mami nanami","ruka sarashina","sumi sakurasawa",
"elaina"
   ]

exports.bisa = [
'BISA',
'Tidak Bisa',
'Oh tentu saja bisa dong',
'Udah dari lahir dia bisa kaya gitu kak 😄',
'Oh tentu saja tidak bisa',
'Wuih bisa bisa',
'Ga mao jawab ah lu wibu',
'Tentu saja bisa eh tapi boong awokawok ',
'Engga engga dia ga bisa',
'Enggaklah',
'Aku ga mao jawbab 🙂',
'Rahasia dong',
'Ulangi Tod gua ga paham',
'Mana gua tau anjir',
]

exports.kapan = [
'Besok',
'Lusa',
'1 Hari Lagi',
'2 Hari Lagi',
'3 Hari Lagi',
'4 Hari Lagi',
'5 Hari Lagi',
'6 Hari Lagi',
'1 Bulan Lagi',
'2 Bulan Lagi',
'3 Bulan Lagi',
'4 Bulan Lagi',
'5 Bulan Lagi',
'6 Bulan Lagi',
'7 Bulan Lagi',
'8 Bulan Lagi',
'9 Bulan Lagi',
'10 Bulan Lagi',
'11 Bulan Lagi',
'1 Tahun lagi',
'2 Tahun lagi',
'3 Tahun lagi',
'4 Tahun lagi',
'5 Tahun lagi',
'6 Tahun lagi',
'7 Tahun lagi',
'8 Tahun lagi',
'9 Tahun lagi',
'10 Tahun lagi',
]


exports.trut = [
'Pernah suka sama siapa aja? berapa lama?',
'Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)',
'apa ketakutan terbesar kamu?',
'pernah suka sama orang dan merasa orang itu suka sama kamu juga?',
'Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?',
'pernah gak nyuri uang nyokap atau bokap? Alesanya?',
'hal yang bikin seneng pas lu lagi sedih apa',
'pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?',
'pernah jadi selingkuhan orang?',
'hal yang paling ditakutin',
'siapa orang yang paling berpengaruh kepada kehidupanmu',
'hal membanggakan apa yang kamu dapatkan di tahun ini',
'siapa orang yang bisa membuatmu sange',
'siapa orang yang pernah buatmu sange',
'(bgi yg muslim) pernah ga solat seharian?',
'Siapa yang paling mendekati tipe pasangan idealmu di sini',
'suka mabar(main bareng)sama siapa?',
'pernah nolak orang? alasannya kenapa?',
'Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget',
'pencapaian yang udah didapet apa aja ditahun ini?',
'kebiasaan terburuk lo pas di sekolah apa?',
]


exports.salam =["P","p","Woy","woy","Oy","oy","hey","Hey"]

exports.oawalah = ['iya kak ?', 'Ada apa kak ?', 'Bot aktif kak', 'Aku bukan bot kak, aku ini hooman', 'Kumaha atuh kak ?', 'Kunaon kak ?', 'oy ?', 'ya ?', 'Kenapa panggil aku', 'Ada apa kak kok panggil aku', 'Naon siah kehed manggil manggil']


exports.message = [
"ah kontol gw gatel bet",
"pengen coli rasanya",
"ahhh memek gw gatel pengen nocol make terong ahhhh gatel memek gw om sewa aku dong🤤🤤🤤🍆",
"kontol gw segede 🍆 😌👌",
"bang gw open bo mau sewa?🥺",
"sange memek gw basah🥵",
"KONTOL GW GATEL😀",
"Nyewa purel buat di ajak ngewe ke oyo gw dah siapin duit 1 m ada yang mau gw booking?😌",
"P emutin kontol gw dong🤤🤤",
"P memek gw basah jilatin dong🥵🥵🥵",
"open bo 5000 perjam sini sama saya minat pc😗",
"aahh ahhh ahhh kimochiehh yameteh kudanil ahhh crottt🥵🥵🤤🤤",
"KAPAN GW DI EWE😭🙏",
"pengin ngewe banget sumpah anjengg🤤",
"pengen di ewe banget sumpahh anjengg🥵🥵"
]

exports.regex = ['bilek', 'banh', 'cum', 'kntl', 'anjing', 'mmk', 'bang', 'wibu', 'pantek', 'pepek', 'hentai']

exports.allemojinya = [
"😀","😃","😄","😁","😆","😅","😂",
"🤣","☺","😊","😇","🙂","🙃","😉",
"😌","😍","🥰","😘","😗","😙","😚",
"😋","😜","😝","😛","🤑","🤗","🤪",
"🤨","🧐","🤓","😎","🤩","🥳","🤡",
"🤠","😏","😒","😞","😔","😟","😕",
"🙁","☹️","😣","😖","😫","😩","🥺",
"😤","😠","😡","🤬","🤯","😶","🥵",
"🥶","😐","😑","😯","😦","😧","😮",
"😲","🥱","😵","😳","😱","😨","😰",
"😢","😥","🤤","😭","😓","😪","😴",
"🙄","🤔","🤭","🤫","🤥","😬","🤐",
"🥴","🤢","🤮","🤧","😷","🤒","🤕",
"😈","👿","👹","👺","💩","👻","💀",
"☠️","👽","👾","🤖","🎃","😺","😸",
"😹","😻","😼","😽","🙀","😿","😾",
"🤲","👐","🙌","👏","🙏","🤝","👍",
"👎","👊","✊","🤛","🤜","🤞","✌",
"🤟","🤘","👌","🤏","👈","👉","👆",
"👇","☝","✋","🤚","🖐","🖖","👋",
"🤙","💪","🦾","🖕","✍️","️🦶","🦵",
"🦿","🤳","🗿","🐦","🦄","👀","🗣",
]








exports.thanks =["hnk","hanks","akasih","ksh","ksih"]

exports.menu = ["menu","Menu","mEnu","menU","mennu","Mana menunya","help","Help"]

exports.bad = ["anjing","Anjing","Memek","Asu","Asw","Bangsat","Tolol","Goblok","Gblk","Ajg","Mmk","memek","bangsat","goblok","tolol","peler","pler","ajg","asw","asu","gblk","mmk","bgst","bngst","anj","anjj","anjg","anjjg","peler","kontol","babi","ngentod","ngetod","co","cok","coo","cook","bacot"]

exports.dosa = ["bokep","ngentot yuk","ngentod yuk","vcs","Vcs","oyo","desah","kocokin"]

exports.faktaunik = ["Negara Indonesia berada di posisi ke-4 sebagai Negara Terindah di Dunia versi situs First Choice.","Di Italia, dalam aturannya minuman Cappuccino hanya boleh di minum sebelum waktu siang.","AS, Australia, Finlandia, Jerman dan Kanada adl negara maju tanpa UN. Tahukah anda sekolah trbaik di dunia ada di Finlandia walau tanpa UN.","","\"Jengkol is very nice\" komentar Pierre Bouvier vokalis Simple Plan.","Tiap satu kali jari kita mengklik mouse komputer, ada 1,42 kalori yang terbakar dalam tubuh. (Penelitian, Convert Anything to Calories).","Di Jepang kuno, prajurit diolesi minyak kodok pada tubuh mereka dengan keyakinan bahwa hal itu akan membuat tubuh mereka antirobek."," Di Jepang, ketiduran saat bekerja (inemuri) dapat ditolerir, karena dipandang sebagai kelelahan yang muncul akibat bekerja terlalu keras.","Gergaji mekanik awalnya diciptakan sebagai alat kedokteran untuk membantu melahirkan bayi.","Jangan sering mengatakan kata  di Australia dan Selandia Baru. Di sana, kata berarti mengajak untuk melakukan hubungan seks.","Jamur merang Laetiporus dikenal sebagai julukan \"ayam hutan\" karena konon rasanya mirip seperti daging ayam goreng.","Kaki katak merupakan hidangan istimewa di eropa. Tahukah Anda: sekitar 80% impor katak Eropa berasal dari Indonesia.","Jika Anda mengetik \"do the harlem shake\" di search bar YouTube, layar akan melakukan Harlem Shake!. [Google Chrome]","Melihat melalui lubang kecil akan segera meningkatkan penglihatan Anda sementara.","YouTube menyebutkan rata-rata ada 4000 video baru Harlem Shake yang diunggah setiap hari. [Yahoo!]","Semut memiliki kuburan sendiri. Tapi tahukah anda: Gurita memiliki kebun dan suka berkebun. (wikipedia)","Coklat mengandung Theobromine, molekul organik yang dapat membantu menguatkan enamel gigi. (Penelitian dari Tulane University).","Wanita 2 kali lebih banyak menggunakan emoticon dalam pesan teks dibandingkan pria. (Penelitian di Rice University)","Biarpun Buzz Aldrin adalah orang kedua yang menginjak di bulan tetapi ia adalah orang pertama yang membuang kotoran di ruang angkasa.","Fakta unik berikutnya adalah, Psikolog mengatakan bahwa mengirim dan menerima pesan teks benar-benar dapat meningkatkan mood Anda ketika Anda merasa kesepian. (Telegraph)","Thailand merupakan satu-satunya negara di Asia Tenggara yang tidak pernah dijajah.","Musik memiliki kemampuan untuk memperbaiki kerusakan otak serta mengembalikan kenangan yang hilang. (cracked .com)"," Perasaan kesepian memicu respon yang sama di otak sebagai rasa sakit fisik. (BBCnews)","Di Cape Town, Afrika Selatan, remaja laki-laki yang memiliki gigi ompong dianggap tampan / maskulin.","Semakin pahit cokelat (tinggi zat theobromine), semakin tinggi manfaatnya. Rajin mengkonsumsi 1bar cokelat/hari dapat menyembuhkan batuk kronis.","Kata \"Mouse\" (tikus) berasal dari turunan Bahasa Sansekerta \"Mus\" yang berarti \"pencuri\".","Tidur Siang (Power Nap) trbukti menambah tinggi badan, dikrnkan saat kita tidur siang hormon pertumbuhan (Growth Hormone) lbh aktif bekerja.","Bilangan prima terbesar di dunia saat ini panjangnya 17 juta digit angka, cukup banyak untuk mengisi 28 lembar halaman pada buku novel.","Menurut sebuah studi, minum teh hijau setelah makan ikan membantu menghalangi zat Mercury yang terkandung dalam ikan memasuki aliran darah."," Memperpanjang usia handphone hingga 4 tahun dapat mengurangi dampak lingkungan sampai 40 persen. [Hasil studi di Swiss]","Duduk bersama dgn teman-teman / keluarga utk makan bersama, dpt meningkatkan kebahagiaan & membantu meringankan depresi. [ehealthnewsdaily]","Abibliophobia adalah fobia atau ketakutan terhadap kehabisan bahan bacaan.","Pada abad pertengahan di Eropa, garam sangat mahal harganya, sehingga disebut sebagai \"emas putih\".","Mengunyah permen karet dapat meningkatkan kemampuan berpikir cepat dan kewaspadaan hingga 10 persen. [Jurnal Brain and Cognition]","Wanita yang sedang stres selama kehamilannya cenderung melahirkan anak-anak yang pemarah. [Institute of Psychiatry, King College London]","","35. Disarankan supaya membeli sepatu pada sore hari. Sebab, setelah seharian berjalan, di sore hari kaki akan membesar 5-8 persen.","Musik memiliki kemampuan untuk memperbaiki kerusakan otak serta mengembalikan kenangan yang hilang. [cracked .com]","Menurut penelitian baru, usia harapan hidup anak band rata-rata lebih tinggi dibandingkan musisi yang memilih solo karir. (detikHealth)","Pulau Dewata Bali merupakan 1 dari 10 pulau paling romantis di dunia. [majalah Travel+Leisure]","Universitas di Jepang selalu melakukan upacara peringatan bagi hewan (contoh: tikus) yang mati dalam pengujian laboratorium. [web.archive .org]","Berkedip memberikan otak Anda istirahat sebentar. [para ilmuan di Japan’s Osaka University]","Wanita yang bahagia dalam sebuah pernikahan akan mengalami berat badan naik setengah pound (0,22 kg) setiap 6 bulan. [DailyMail]","Rasa cemburu berlebihan bisa digolongkan penyakit jiwa, krna dpt mendorong ssorg utk bunuh diri / menghabisi nyawa org lain. [riset]","","Mengkonsumsi buah tomat beberapa kali dlm kurun waktu seminggu dpt mengatasi perasaan depresi. [peneliti di Tianjin Medical Univ., Cina]"," Perasaan kesepian memicu respon yang sama di otak sebagai rasa sakit fisik. [BBCnews]","Di Cape Town, Afrika Selatan, remaja laki-laki yang memiliki gigi ompong dianggap tampan / maskulin.","Memeluk orang yg disayangi dpt membantu menurunkan tekanan darah, mengurangi stres dan","kecemasan, bahkn dpt meningkatkan memori. [Dailymail]","Kata \"Mouse\" (tikus) berasal dari turunan Bahasa Sansekerta \"Mus\" yang berarti \"pencuri\".Berjalan kaki atau bersepeda ke sekolah mempertajam konsentrasi siswa di kelas dan tetap bertahan sekitar 4 jam kemudian. [Medical Daily]","Menurut riset pasar global Euromonitor International, pria Korea adalah pria yang paling suka bersolek dari pria lain di dunia.","Rata-rata orang akan merasa 100 persen sehat / fit hanya 61 hari dalam setahun. (Penelitian di Inggris)","Polydactyl Cat adalah jenis kucing yang memiliki jempol di kaki mereka.","Hanya dengan mengurangi brightness dari televisi, anda mampu berhemat lebih dari Rp 1,5 juta setahun. [kompas]","Di Jerman, tahanan yg ingin meloloskan diri dr penjara adl bukan mrupakn perbuatan ilegal. Krn itu salah1 naluri dasar manusia untuk kebebasan.","Wanita merasa diri mereka terlihat paling jelek dan terlihat lebih tua pada hari Rabu pukul 15.30 . [studi baru dari St Tropez]Orang yang rutin bermain video game ternyata memiliki penalaran yang baik dibanding kebanyakan orang. (detikHealth)","Nama \"Gorila\" berasal dari kata Yunani \"Gorillai\" yang berarti \"perempuan berbulu\".","IBM mengatakan bahwa dalam kurun waktu 5 tahun ke depan, komputer bakal mirip manusia yang bisa melihat, mendengar, mencium dan merasakan.","Selama abad ke-13, kata \"nice\" sebenarnya berarti “stupid”, \"senseless\" dan “foolish\".","59. 49% dari pemilik Smartphone adalah jomblo. (Survei, \"2012 Online User Behavior and Engagement Study\")","Fakta Unik","60. Gazzarella adalah keju mozzarella yang terbuat dari susu kucing. 61. Rata-rata orang melihat / mengecek ponselnya sekitar 150 kali sehari. (Laporan Nokia pada MindTrek 2010)","Lalat dapat menyalurkan sekitar 300 bakteri setiap kali hinggap di benda.","Tertawa dapat meningkatkan aktivitas antibodi sekitar 20%, juga membantu untuk menghancurkan virus dan sel-sel tumor.","Fobia matematika (mathematics anxiety) memicu respon yang sama di otak sbg rasa sakit fisik. Gejalanya yaitu melihat angka saja sudah nyeri."," Karakter kartun Bugs Bunny diberi pangkat kehormatan sersan-mayor di Korps Marinir AS pada akhir Perang Dunia II. (wikipedia)","Apel yang ditaruh di ruang terbuka akan matang 10 kali lebih cepat dibandingkan dengan apel yang ditaruh di kulkas.","Ungkapan 'Smitten' adalah untuk menyebut 'naksir' dalam bahasa Inggris.","Menurut etiket internasional, sebuah jabat tangan yang tepat dan baik harus berlangsung selama sekitar 3 detik & dilepaskan setelah goyang.","Ketika kita sedang jatuh cinta, otak akan memproduksi dopamin ekstra, bahan kimia yang membuat seseorang menjadi gembira berlebihan."," \"Mwahahaha\" dan \"lolz\" telah ditambahkan ke Kamus Inggris Oxford.","Menurut penelitian, pria cenderung menurunkan volume suaranya ketika ia berbicara dg seseorang yg ia cintai, sementara perempuan sebaliknya.","Di Perancis, jajanan Arum Manis (Rambut Nenek) disebut \"Barbe á Papa\" yang berarti \"Jenggot Ayah\".","Menurut penelitian, PR terlalu banyak sebenarnya dapat menyebabkan siswa menjadi stres, depresi & mendapat nilai lebih rendah.","Hangry adalah penggabungan kata dari \"Hungry\" dan \"Angry\", di pakai ketika anda sedang lapar dan marah.","Kentut dari bakteri membuat keju swiss memiliki lubang-lubang.","Mendengarkan musik benar-benar dapat mengurangi rasa sakit kronis hingga 20% dan membantu meringankan depresi hingga 25%. (sciencedaily)","Orang yang merasa kesepian memiliki kemungkinan mengalami kepikunan 70-80% lebih tinggi. (Journal of Neurosurgery Neurologi and Psychiatry)","Melamun dpt memendekkan telomere (bagian paling ujung sel DNA) yang berperan dlm menjaga kestabilan sel, dimana dapat mempercepat proses penuaan."]

exports.pantun = ["\nAnak tikus rindu ibunya\n\nsombong nich ceritanya","\nAda kepompong ada kupu\n\nbales donk sms dari aku","\nBeli bandeng\n\ndi Malaysia\n\ngue ganteng\n\nkayak Pasha","\nHati siapa tak bimbang\n\nsitu botak minta dikepang","\nBuah semangka\n\nbuah duren\n\nnggak nyangka\n\ngue keren\n ","\n Mawar bersemi\n\ndi batang kayu\n\ndo you love me\n\nlike i love you","\nBurung perkutut\n\nburung kuthilang\n\nkamu kentut\n\nenggak bilang bilang","\nBread is roti\n\nshadow is bayang\n\nbefore you mati\n\nbetter you sembahyang","\nJangan takut\n\njangan khawatir\n\nitu kentut\n\nbukan petir","\nBeli ikan di pasar malam\n\ndasar bego ni kawan","\nMakan duren sambil ngelamun,\n\nHati-hati ketelen ntar bijinya","\nDi  sana gunung, di sini gunung\n\nCiptaan Tuhan deh","\nKan bandeng\n\nmakan kawat\n\norang ganteng\n\nnumpang lewat","\nOrang ganteng\n\nsuka sama si Rini\n\ngak seneng\n\nmaju sini","\nMelon manis di air es\n\nke mana aja lo gak pernah sms","\nJambu merah\n\ndi dinding\n\njangan marah\n\njust kidding","\nBuah semangka\n\nbuah manggis\n\nnggak nyangka\n\ngue manis","\nMen sana\n\nin corpore sano\n\ngue maen ke sana,\n\nelo maen ke sono!","\nBuah apel\n\ndi air payau\n\nnggak level\n\nlayauuuuuuu","\nDi sini bingung, di sana linglung\n\nemangnya enak, enggak nyambung…","\nBuah semangka berdaun sirih\n\nBuah ajaib kali yah","\nPilih suara harpa yang jelas.\n\nTali di harpa diikat cinta","\nCiuman di pipi\n\nciuman di dahi\n\nApa yang dicium sesudah lah cinta?","\nSepandai-pandai tupai melompat\n\nPolisi lebih pandai melompat","\nDua tiga kacang tanah\n\nenggak ada pacar yang datang ke rumah","\nDapet kado isinya tomat\n\nBodo amat!!","\nDulu delman, sekarang gokar\n\ndulu teman, sekarang pacar","\nStroberi mangga apel\n\nsorry gak level","\nBola pingpong dimakan gelatik\n\nBiar ompong yang penting cantik\n","\nMata belo,\n\nala komedian.\n\ngue sama elo?\n\nmaunya jadian.","\nTunda lapar,\n\nmakan indomi.\n\nhati menggelepar,\n\ncintapun bersemi.","\nPotong kuku,\n\npendek-pendek.\n\nhatiku beku,\n\nsi abang mendadak ngondek.","\nBeli ketan,\n\nbeli kain songket.\n\nbiar udah mantan,\n\nkita tetep lengket.","\nKe pasar, nyari obat gatal\n\nDasar, gak modal!","\nMakan semangka,\n\nmakan kedondong.\n\nkalau suka,\n\nnyatain dong.","\nGa punya pendirian,\n\nbikin jemu.\n\nga mau sendirian,\n\nmaunya bobo sama kamu.","\nNembak itik,\n\nlangsung kena.\n\nkamu cantik,\n\nhey nona!","\nKotak amal,\n\ndigoyang-goyang.\n\nkemarin aku diramal,\n\njodohnya sama abang.","\nHari Jumat,\n\npada pake batik.\n\nsalam hormat,\n\nbuat neng cantik.","\nPecahan genting,\n\ndi bawah kursi.\n\nbetah meeting,\n\nkarena si boss seksi.","\nNangis-nangis,\n\nmobil kena srempet.\n\nneng manis,\n\nmau dong dipepet.","\nPanasin mentega,\n\nkarena mulai beku.\n\nkamu mau ga,\n\njadi imamku?","\nPotong sebahu,\n\nbiar ga sendu.\n\nkamu tahu?\n\nAku rindu.","\nJangan tanya,\n\nkapan lulus kuliah.\n\nga dapet anaknya,\n\nmamanya boleh lah","\nBikin anak,\n\ndi pojokan sekolah\n\nkalau mau enak,\n\nnikah dulu lah.","\nMain mata,\n\nmesem-mesem.\n\nneng tetep cinta,\n\nbiarpun abang keteknya asem.","\nTiduran di tandu,\n\nberjam-jam.\n\nhati merindu,\n\nmata sulit memejam.","\nUbek-ubek peti,\n\ncari gunting.\n\nsaking cinta mati,\n\nneng rela bunting.","\nNamanya penjahat,\n\npolisi jadi inceran.\n\nbosan jadi temen curhat,\n\nmaunya pacaran.","\nKe salon creambath,\n\nbiar aliran darah lancar.\n\nbosen ah jadi sahabat,\n\nmaunya jadi pacar!"]

exports.truthdare = {"Truth":{"id":["Benar atau tidak bahwa orang yang kamu sukai berada diantara kita semua saat ini?","Sebutkan kejadian paling memalukan yang pernah kamu alami?","Kamu pernah kesal dan membenci aku bukan?","Kamu berpura-pura datang ke kelas sebelah hanya untuk melihat gebetanmu bukan?","Siapa orang yang paling jago bikin kamu tertawa terbahak-bahak?","Ceritakan kejadian yang membuatmu marah besar kepada kakak?","Siapa mantan terindah yang pernah kamu miliki?","Ayo jujur, kamu pernah ada niat untuk kembali berpacaran dengan mantanmu bukan","Beritahu kita semua nama orang yang pernah menolak pernyataan cintamu dulu","Belajar online tapi banyak tugas PR atau belajar disekolah tapi banyak jam kosong?","Siapa yang paling sesuai dengan tipe idealmu di antara anak kelas?","Kasih tau gosip paling parah tentang anak sekolah yang kamu rahasiakan dari kita semua","Apa yang menyebab phobia yang kamu miliki sampai sekarang apa?","Kapan terakhir kali kamu mengompol di celana","Baju terjelek yang pernah dipakai oleh kakak apa? Yang jujur ya jawabnya","Siapa yang gaya berpakaiannya paling payah diantara kita semua?","Barang termurah yang di pakai dan barang termahal yang pernah kamu pakai","Beritahu sifat buruk dari kita semua yang menurut kamu sangat menyebalkan sekali?","Sebutkan film dan lagu yang pernah membuatmu menangis tersedu-sedu","Jalan-jalan ke puncak tapi besoknya ujian atau sekolah tapi banyak jam kosong","Moment paling romantis yang pernah dilakukan kekasihmu apa?","Moment menjijikan yang pernah kamu lihat dan tidak ingin terjadi lagi adalah","Jika kamu mempunyai kekuatan super, kekuatan apa yang ingin kamu miliki?","Kalau kamu dijodohkan oleh papa dan mama, kamu setuju atau tidak?","Jujur, kamu sangat tidak suka kalau papa dan mama mulai membandingkan mu dengan saudara lainnya?","Kalau biaya operasi plastik murah, kamu ingin memiliki wajah seperti artis mana?","Sebutkan kebohongan terbesar yang pernah kamu lakukan kepada mama dan papa?","Kalau besok adalah hari kiamat, kamu ingin menghabis moment terakhir dihidupmu bersama dengan siapa?","Jika kamu dikasih kesempatan untuk reinkarnasi, kamu ingin menjadi siapa pada kehidupan selanjutnya?","Kamu pernah melakukan sebuah pencurian atau tidak?","Jika kamu diberikan kesempatan untuk bertukar kehidupan, kamu ingin bertukar kehidupan selama sehari dengan siapa?","Pilih pacar ngajak jalan berdua dan temen-temen ngajak main bersama-sama?","Diantara kita semua, siapa yang paling tidak bisa berpose dan bergaya ketika di foto?","Masakan siapa diantara kita yang memiliki rasa yang tidak enak?","Jujur, kamu pernah buntutin pacar kamu buat mergokin dia lagi selingkuh kan?","Kamu pernah kepoin mantannya pacar kamu kan cuma buat bandingin visual kamu sama dia?","Jujur ya, kamu pernah ga kentut di dalam kelas?","Apakah kamu pernah memarahi adikmu dan membuatnya menangis?","Apa hal yang paling menjengkelkan yang pernah dilakukan kakak kepada kamu?","Kenapa kamu suka ngelarang adik buat cek meja belajarmu?","Sebutkan mimpi buruk yang paling mengerikan dan nyaris pernah kamu alami?","Apakah kamu hampir mengalami kecelakaan dulunya?","Jika kamu sedang bersedih, galau dan kesal, kamu akan meredakan hal tersebut dengan melakukan apa?","Ayo jujur, kamu selalu menuliskan rasa suka mu terhadap kakak kelas A di buku harianmu bukan?","Sebutkan nama penggilan dimasa kecil yang kamu miliki?","Kamu takut sama hewan apa saja?","Kapan terakhir kali kamu memeluk mama dan papa?","Moment membahagiakan yang pernah kamu alami dalam hidupmu apa?","Kamu pernah cemburu sama adikmu kan karena kamu merasa orang tuamu lebih sayang dengan adikmu ketimbang dirimu sendiri?"],"eng":["Is it true or not that the person you like is among all of us right now?","What is the most embarrassing incident youve ever experienced?","Youve been annoyed and hated me, right? ","You pretend to come to the next class just to see your crush right?","Who is the person who is the best at making you laugh out loud? ","Tell me an incident that made you angry with brother? ","Who is the most beautiful ex you have ever had? ","Lets be honest, you never had the intention of dating your ex again","Tell us all the names of people who have rejected your first love statement","Studying online but having a lot of homework assignments or studying at school but lots of free hours? ","Who is the most suitable for your ideal type among the class children?","Tell us the worst gossip about school children that you keep secret from us all","What causes the phobia that you have until now? ","When was the last time you peed your pants","What are the worst clothes youve ever worn? The honest answer is yes","Who is the worst dresser of all of us? ","The cheapest item used and the most expensive item you've ever used","Tell us the bad qualities of all of us that you think are very annoying?","Name the movies and songs that made you cry the most.","Going to the top but the next day is exam or school but many hours are empty"," What is the most romantic moment your lover has ever done? ","The nastiest moment you've seen and don't want to happen again is"," If you have super powers, what strength would you want to have? ","If you are arranged by father and mother, do you agree or not? ","Honestly, you really dont like it when papa and mama start comparing you with other siblings? ","If the cost of plastic surgery is cheap, which artist would you like to have a face? ","What is the biggest lie youve ever done to mama and papa? ","If tomorrow is the Day of Judgment, who do you want to spend the last moment of your life with? ","If you were given the opportunity to reincarnate, who would you like to be in the next life? ","Have you ever committed a theft or not? ","If you were given the opportunity to swap lives, who would you like to swap lives for a day with?","Choose your boyfriend to invite you to hang out together and your friends to invite you to play together? ","Among all of us, who is the least able to pose and style when in photos?","Who among us has a bad taste? ","Honestly, you have been following your boyfriend to catch him cheating, right? ","Have you ever asked your ex-boyfriend to just make a visual comparison between you and him? ","Honestly, have you never farted in class? ","Have you ever scolded your sister and made her cry? ","Whats the most annoying thing you ve ever done to you? ","Why do you like to prevent your sister from checking your study table? ","What is the most terrible nightmare you have ever had? ","Did you almost have an accident before?","If you are sad, upset and upset, what will you relieve it by doing? ","Let s be honest, you always write down how you like seniors A in your diary right? ","What are the names of childhood calls that you have? ","Are you afraid of any animal? ","When was the last time you hugged mom and dad? ","What are the happy moments that you have experienced in your life? ","You were jealous of your younger siblings, right because you felt that your parents loved your younger siblings more than you did? "]},"Dare":{"id":["Nyanyikanlah sebuah lagu yang harus dibawakan dengan penuh penghayatan di depan semua orang saat ini","Ayo chat mantan atau gebetanmu dan ketiklah aku kangen kamu lalu kirim. Mari tunggu apa belasan dan reaksinya","Kamu harus menarikan sebuah lagu India dengan diiringi oleh backsound panci dan baskom yang ditabuhkan","Makan dan telan buah lemon sampai habis tanpa tersisa dan tidak boleh dibuang","Ajaklah orang yang tidak kamu kenal untuk menari bersama","Memakai celana legging secara cepat tanpa menggunakan tangan dan hanya diperbolehkan menggunakan kaki","Panggil orang secara random dan katakanlah kamu tampan atau cantik kepada orang tersebut","Gelitiki teman sebangkumu tanpa mengatakan apa alasan dibalik kau melakuka hal tersebut","Larilah ke tengah lapangan seraya menjerit dan mengatakan bahwa aku rindu pada mantanku","Uploadlah sebuah video pada akun sosial media pribadi dimana kamu menarikan sebuah lagu dengan penuh semangat","Ajak orang yang tidak kamu kenal untuk selfie berdua dengan mu lalu upload ke snapgram","Ambil beberapa nomor dari kontakmu secara acak dan kirim sms \"Aku hamil\" sama mereka","Ambil minuman apa saja yang ada didekat mu lalu campurkan dengan cabai dan minum!","Ambil nomor secara acak dari kontakmu, telepon dia, dan bilang \"Aku mencintaimu\"","Beli makanan paling murah di kantin (atau beli sebotol aqua) dan bilang sambil tersedu-sedu pada teman sekelasmu \"Ini.adalah makanan yang paling mahal yang pernah kubeli\"","Beli satu botol coca cola dan siram bunga dengan coca cola itu di depan orang banyak.","Berdiri deket kulkas, tutup mata, pilih makanan secara acak didalemnya, pas makanpun mata harus tetep ditutup.","Berdiri di tengah lapangan basket dan berteriak, \"AKU MENCINTAIMU PANGERANKU/PUTRIKU\"","Beri hormat pada seseorang di kelas, lalu bilang \"Hamba siap melayani Anda, Yang Mulia.\"","Berjalan sambil bertepuk tangan dan menyanyi lagu \"Selamat Ulang Tahun\" dari kelas ke koridor.","Berlutut satu kaki dan bilang \"Marry me?\" sama orang pertama yang masuk ke ruangan.","Bikin hiasan kepala absurd dari tisu, apapun itu, terus suruh pose didepan kamera, terus upload","Bikin hiasan kepala absurd dari tisu, apapun itu, terus suruh pose didepan kamera, terus upload","Bilang \"KAMU CANTIK/GANTENG BANGET NGGAK BOHONG\" sama cewek yang menurutmu paling cantik di kelas ini","Bilang pada seseorang di kelas, \"Aku baru saja diberi tahu aku adalah kembaranmu dulu, kita dipisahkan, lalu aku menjalani operasi plastik. Dan ini adalah hal paling serius yang pernah aku katakan.\"","Buang buku catatan seseorang ke tempat sampah, di depan matanya, sambil bilang \"Buku ini isinya tidak ada yang bisa memahami\"","Cabut bulu kaki mu sendiri sebanyak 3 kali!","Chat kedua orangtuamu, katakan bahwa kamu kangen dengan mereka lengkap dengan emoticon sedih.","Coba searcing google mengenai hal-hal yang mengerikan atau menggelikan seperti trypophobia, dll.","Duduk relaks di tengah lapangan basket sambil berpura-pura itu adalah pantai untuk berjemur.","Duduk relaks di tengah lapangan basket sambil berpura-pura itu adalah pantai untuk berjemur.","isi mulut penuh dengan air dan harus tahan hingga dua putaranJika tertawa dan tumpah atau terminum, maka harus ngisi ulang dan ditambah satu putaran lagi.","Salamanlah dengan orang pertama yang masuk ke ruangan ini dan bilang \"Selamat datang di Who Wants To Be a Millionaire!\"",".Kirim sms pada orangtuamu \"Hai, bro! Aku baru beli majalah Playboy edisi terbaru!\"","Kirim sms pada orangtuamu, \"Ma, Pa, aku sudah tahu bahwa aku adalah anak adopsi dari Panti Asuhan. Jangan menyembunyikan hal ini lagi.\"","Kirim sms pada tiga nomor acak di kontakmu dan tulis \"Aku baru saja menjadi model majalah Playboy.\"","Makan satu sendok makan kecap manis dan kecap asin!","Makan sesuatu tapi gak pake tangan.","Marah-marahi ketemen kamu yang gak dateng padahal udah janjian mau main \"truth or dare\" bareng\"","Pecahkan telur menggunakan kepala!","Makanlah makanan yang sudah dicampur-campur dan rasanya pasti aneh, namun pastikan bahwa makanan itu tidak berbahaya untuk kesehatan jangka panjang maupun jangka pendek.","Menari ala Girls' Generation untuk cowok di depan kelas, atau menari ala Super Junior untuk cewek.","Mengerek tiang bendera tanpa ada benderanya.","Menggombali orang yang ditaksir, sahabat terdekat, lawan jenis yang tidak dikenal sama sekali dan  sejenisnya.","Meniru style rambut semua temen kamu.","Menyanyikan lagu HAI TAYO di depan banyak orang sambil menari","Menyanyikan lagu Baby Shark dengan keras di ruang kelas.","Minjem sesuatu ke tetangga","Minta tandatangan pada seorang guru yang paling paling galak sambil bilang \"Anda benar-benar orang yang paling saya kagumi di dunia.","Minta uang pada seseorang (random/acak) di jalan sambil bilang \"Saya tidak punya uang untuk naik angkot.\"","Minum sesuatu yang udah dibuat/disepakatin, tapi pastiin gak berbahaya, bisa kayak minum sirup yang digaremin terus ditambah kecap.","follow ig @rayyreall"],"eng":["Sing a song that must be sung passionately in front of everyone at this time","Let's chat your ex or crush and type I miss you then send. Let's wait a dozen and their reaction","You have to dance to an Indian song accompanied by the backsound of the pot and basin being played","Eat and swallow the lemon until it runs out without remaining and should not be thrown away","Invite people you don't know to dance together","Wear leggings quickly without using your hands and only allowed to use your feet","Call a random person and say you are handsome or beautiful to that person","Tickle your seatmate without saying what the reason is behind you doing it","Run into the middle of the field screaming and saying that I miss my ex","Upload a video on your personal social media account where you dance a song with gusto","Invite someone you don't know to take a selfie together with you then upload it to snapgram","Get random numbers from your contacts and text them\" I'm pregnant ","Take any drink that is near you then mix it with chilies and drink!","Get a random number from your contact, call him, and say \"I love you\"","Buy the cheapest food in the canteen (or buy a bottle of aqua) and tell your classmate sobbing \"This. is the most expensive food I've ever bought \"","Buy a bottle of coca cola and splash the flowers with the coca cola in front of the crowd.","Stand near the refrigerator, close your eyes, choose food randomly inside, even when you eat your eyes must be closed .","Stand in the middle of a basketball court and shout, \"I LOVE MY PRINCESS / MY PRINCESS","Pay respect to someone in class, then say\" Servant at your service, Your Majesty. ","Walk clapping and singing the song\" Happy Birthday \"from the classroom to the corridor .","Get on one knee and say\" Marry me? \" same as the first person who entered the room","Make absurd headdresses from tissue, whatever it is, keep asking poses in front of the camera, keep uploading","Say\" YOU'RE BEAUTIFUL / GANTENG SO AWESOME \"to the girl you think is the most beautiful in this class","Tell someone in class, \"I was just told I was your twin first, we were separated, then I had plastic surgery. And this is the most serious thing I have ever said.","Throw someone's notebook into the trash, in front of his eyes, saying \"This book's contents no one can understand\"","Pull out your own leg hair 3 times!","Chat between your parents, say that you miss them complete with sad emoticons .","Try searcing google about horrible or ridiculous things like trypophobia, etc.","Sit back and relax in the middle of the basketball court pretending it's a sunbathing beach .","fill mouth full of water and have to hold up to two rounds. If you laugh and spill or drink, then you have to refill and add one more round .","Shake hands with the first person to enter this room and say \"Welcome to Who Wants To Be a Millionaire!","Send a text message to your parents\" Hi, bro! I just bought the latest issue of Playboy magazine!","Send a text to your parents, \"Ma, Pa, I already know that I am an adopted child of the orphanage. Don't hide this anymore.","Send a text to three random numbers in your contact and write \"I just became a Playboy magazine model.\"","Eat one tablespoon of sweet soy sauce and soy sauce! ''","Eat something but don't use your hands .","Get angry with your friends who didn't come even though they promised to play \"truth or dare\" together \"","Break the egg using the head!","Eat food that has been mixed and it must be strange, but make sure that the food is not harmful to long term or short term health .","Dancing Girls' Generation style for boys in front of the class, or dancing Super Junior style for girls .","hoist flagpole without flag .","Digging up your crush, closest friends, the opposite sex you don't know at all and the like.","Replicate the hairstyles of all your friends .","Singing the HAI TAYO song in front of a large crowd while dancing","Sing the Baby Shark song loudly in the classroom.","Send something to the neighbor","\"Get an autograph on the fiercest teacher while saying\" You are truly the person I admire the most in the world. \"","Asking someone (random / random) on the street for money saying \"I don't have money to take an angkot.\"","Drink something that has been made / agreed upon, but make sure it's not dangerous, like drinking salted syrup and adding soy sauce.\"","follow ig @ rayyreall"]}}
