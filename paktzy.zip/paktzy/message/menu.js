const fs = require("fs")
const chalk = require("chalk")

exports.menunya = (m) => {
return `
╭──(          VannStore.         )
║- Sc Private 友
│🎭 Name : ${m.pushName}
║▬▭▬▭▬▭▬▭▬▭
│🎭 Creator :  Pak - Tzy
║🎭 Prefix : MULTI
│▬▭「 VannStore️ 」▭▬
║
│ YouTube : https://youtube.com/c/PakTzy
║ YouTube : https://youtube.com/@VanMaker02
║
┗━━━━━━━━━━━━━━━━━━⬣
╔─═─═⊱ *「 JOIN GROUP 」* ─═─═⬣
│┏⊱
║⿻ *Group V1!!〽️ : -
│⿻ *Group V2!!〽️ : -
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
┏━━━━━━━━━━━━━━━━━━⬣
║┏⊱
│║- Sc Private 友
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 OWNER MENU 」* ─═⬣
│┏⊱
║⿻ Join
│⿻ Leave
║⿻ Creategc
│⿻ Bc
║⿻ Bcgc
│⿻ Bcpc
║⿻ Getcase
│⿻ Ban
║⿻ Unban
│⿻ Block
║⿻ Unblock
│⿻ Setppbot
║⿻ Setnomerowner
│⿻ Setnamaowner
║⿻ Setcopyright
│⿻ Setmenu
║⿻ Setreply
│⿻ Setwelcome
║⿻ Auto
│⿻ Autosticker
║⿻ Autorespon
│⿻ Autoread
║⿻ Autovn
│⿻ Anticall
║⿻ Mode
│⿻ Getfile
║⿻ Getfolder
│⿻ Getsesi
║⿻ Chat
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═─⊱ *「 VIRUS & BUG 」* ─═─⬣
│┏⊱
║⿻ Bugtag [ Bug @ ]
│⿻ Bugreacpc [ Nomor Target ]
║⿻ Vncrash [ Nomor Target ]
│⿻ Bugreacgc [Id Group]
║⿻ Bugsticker [ PC / GC ]
│⿻ Catalogc [ Crash Home ]
║⿻ Catalog+ [ Crash Home + IDR ]
│⿻ Catalog [ IDR ]
║⿻ Catalog2 [ PC  / GC ]
│⿻ Bugbutton [ Jumlah ]
║⿻ Virkon [ 86 CTT ]
│⿻ Fotoc [ Nomor Target ]
║⿻ Pdfcrash [ Pc / Gc ]
│⿻ Buglist [ New Md ]
║⿻ Virvid [ Pc / Gc ]
│⿻ Senbug [ Pilihan ]
│⿻ Jadibug1 [ Reply ]
║⿻ Jadibug2 [ Reply ]
│⿻ Jadibug3 [ Reply ]
║⿻ Jadibug4 [ Reply ]
│⿻ Jadibug5 [ Reply ]
║⿻ Permisi [ Bug List ]
│⿻ Bugstik [ Jumlah ]
║⿻ Bughen [ Nomor Target ]
│⿻ Virdoc [ Document ]
║⿻ Inibug [ Jenis Tagal ]
│⿻ Catalog3 [ Pc / Gc ]
║⿻ Troli [ Troli Cart ]
│⿻ Gascrash [ Pc ]
║⿻ Bug1 [ Bug Jenis Audio ]
│⿻ Bug2 [ Bug Jenis Foto ]
║⿻ Bug3 [ Bug Jenis Doc ]
│⿻ Bug4 [ Bug Jenis Grup ]
║⿻ Bug5 [ Bug Jenis Lokas ]
│⿻ Bug6 [ Bug Jenis Troli ]
║⿻ Bug7 [ Bug Jenis Ctt ]
│⿻ Listcrash [ Pc ]
║⿻ Cart [ Pc / Gc ]
│⿻ Cttcrash [ Pc ]
║⿻ Dokcrash [ Pc / Gc ]
│⿻ Audiocrash [ Pc / Gc ]
║⿻ Oncrash [ Vitur Grup ]
│⿻ Cttall [ Pc ]
║⿻ Virkonc [ Ctt ]
│⿻ Pdfspam [ Jumlah ]
║⿻ Bugpdf [ Pdf ]
│⿻ Spam [ Jumlah ]
║⿻ Bugpc [ Buginvite ]
│⿻ Bannum [ Report ]
║⿻ Unbannum [ Support ]
│⿻ Pccrash [ Pc ]
║⿻ Lokas [ Live Lokasi ]
│⿻ Livelok [ Pc / Gc ]
║⿻ Tzycrashpc [ Nomor Target ]
│⿻ Image [ Pc / Gc ]
║⿻ Tzycrashgc [ Id Gc ]
│⿻ Cttbusin [ Pc ]
║⿻ Poll [ Pol+Txt Kosong ]
│⿻ Votpol [ Vote Crash ]
║⿻ Polvote [ Teks ]
│⿻ Troli2 [ CartV2 ]
║⿻ Paym [ Virtex Pay ]
│⿻ Paymv [ V Pay Thum Img ]
║⿻ Stpc [ Pc ]
│⿻ Stgc [ Gc ]
║⿻ Doc [ Virdoc New V1 ]
│⿻ Docu [ Virdoc New V2 ]
║⿻ Virduc [ Virdoc New V3 ]
│⿻ Duc [ Virdoc New V4 ]
║⿻ Spamv [ Jumlah ]
│⿻ Afk [ Reaction Emoji ]
║⿻ Vaudio [ Virus Media ]
│⿻ Pengsui [ Text Kosong ]
║⿻ Vimgsw [ Reply Foto ]
│⿻ Vionce [ Virus Once Img ]
║⿻ Vvonce [ Reply Video ]
│⿻ Vvidsw [ Virvid Sw ]
║⿻ Troli4 [ Cart Crash ]
│⿻ Vtag [ Tag Di Gc ]
║⿻ Bugvid [ View Vid Crash ]
│⿻ Vbuy [ V Click Bayar ]
║⿻ Buglink [ Virus Link ]
│⿻ Vweb [ Virus Website ]
║⿻ Jadicatalogc [ Reply Img+Txt ]
│⿻ Jadicatalog+ [ Reply Img+Txt ]
║⿻ Vgt [ V Web ]
│⿻ Vgs [ V Web ]
║⿻ Jadicatalog [ Reply Foto ]
│⿻ Jadibugsw [ Reply Img+Txt ]
║⿻ 🔥 [ Bug Bew ]
│⿻ Bugytta [ Button 6 ]
║⿻ Buttonimg [ Img Bug Button ]
│⿻ Bugquick [ Button 9 ]
║⿻ ⚠️ [ Dangerr ]
│⿻ Ftroli [ Cart ]
║⿻ Santed [ Brutal Send ]
│⿻ Santedgc [ Masukan Link ]
║⿻ Sendbug [ V1 ]
│⿻ Sendbugv [ V2 ]
║⿻ Sendbuggc [ V3 ]
│⿻ Sendbuggcv [ V4 ]
║⿻ Bugdelete [ Ghost ]
│⿻ Kudeta [ Kudet Grup ]
║⿻ Autobug [ On/Off ]
│⿻ Bug [ Jids ]
║⿻ Culikall [ Cilik All Mem ]
│⿻ Culik [ Tag Mem ]
║⿻ Hacked [ Bot Admin ]
│⿻ Retasgc [ Option ]
║⿻ Kenon [ FORM WA ]
│⿻ Verif@ [ Masukan Nomor ]
║⿻ > Aud
│⿻ > Aud1
║⿻ > Buttontzy
│⿻ > Buttonvirus
║⿻ > Cttl
│⿻ > Ker
║⿻ > Mata
│⿻ > Mata1
║⿻ > Notif1
│⿻ > Notif2
║⿻ > Notif3
│⿻ > Notif4
║⿻ > Pen
│⿻ > Place
║⿻ > Tizi
│⿻ > Url
║⿻ > Weg
│⿻ > Pvz3
║⿻ > Pvm3
│⿻ > Funer
║⿻ > Pv3m
│⿻ > Lugia
║⿻ > Malvadinha
│⿻ > Explosion
║⿻ > Parando
│⿻ > Killed
║⿻ > Cova
│⿻ > Sumiu
║⿻ > Destroi
│⿻ > Voids
║⿻ > Explosionios
│⿻ > Vimg
║⿻ > Vimgesw
│⿻ > Konf
║⿻ > Vnolim
│⿻ Viospc+ [ Private Chat ]
║⿻ Viospc [ Private Chat ]
│⿻ Vandropc [ Private Chat ]
║⿻ Viosgc+ [ Group Chat ]
│⿻ Viosgc [ Group Chat ]
║⿻ Vandrogc [ Group Chat ]
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 GROUP MENU 」* ─═⬣
│┏⊱
║⿻ Antilink
│⿻ Antilinkgc
║⿻ Antilinkyt
│⿻ Antilinkfb
║⿻ Antilinkig
│⿻ Antilinktele
║⿻ Antilinkwa
│⿻ Antilinktiktok
║⿻ Antilinktwitter
│⿻ Antivirtex
║⿻ Antiasing
│⿻ Antitag
║⿻ Antidelete
│⿻ Antiviewonce
║⿻ Antitoxic
│⿻ Antisange
║⿻ Antinsfw
│⿻ Autorespongc
║⿻ Autoreact
│⿻ Mute
║⿻ Welcome
│⿻ Linkgc
║⿻ Setppgroup
│⿻ Setnamegc
║⿻ Setdesc
│⿻ Group
║⿻ Revoke
│⿻ Hidetag
║⿻ Tagall
│⿻ Add
║⿻ Kick
│⿻ Promote
║⿻ Demote
│⿻ Opentime
║⿻ Closetime
│⿻ Disappearing
║⿻ Editinfo
│⿻ Inspect
║⿻ Vote [Text]
│⿻ Devote
║⿻ Upvote
│⿻ Cekvote
║⿻ Hapusvote
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 TOLS MENU 」* ─═⬣
│┏⊱
║⿻ Menu
│⿻ Owner
║⿻ Kalkulator
│⿻ Getpp
║⿻ Getname
│⿻ Wame
║⿻ Del
│⿻ Delsampah
║⿻ React
│⿻ Runtime
║⿻ Speed
│⿻ Ping
║⿻ Listpc
│⿻ Listgc
║⿻ Cariteman
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 STORAGE MENU 」* ─═⬣
│┏⊱
║⿻ Addstick
│⿻ Addvn
║⿻ Addowner
│⿻ Delstick
║⿻ Delvn
│⿻ Delowner
║⿻ Liststick
│⿻ Listvn
║⿻ Listowner
│⿻ Listban
║⿻ Listblock
│⿻ Clearallstick
║⿻ Clearallvn
│⿻ Clearallowner
║⿻ Clearallban
│⿻ Clearalldb
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 JADIBOT MENU 」* ─═⬣
│┏⊱
║⿻ Jadibot
│⿻ Stopjadibot
║⿻ Deljadibot
│⿻ Clearalljadibot
║⿻ Listjadibot
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 FUNN MENU 」* ─═⬣
│┏⊱
║⿻ Bagaimanakah
│⿻ Kapankah
║⿻ Apakah
│⿻ Bisakah
║⿻ Rate
│⿻ Wangy
║⿻ Gantengcek
│⿻ Cekganteng
║⿻ Cantikcek
│⿻ Cekcantik
║⿻ Sangecek
│⿻ Ceksange
║⿻ Gaycek
│⿻ Cekgay
║⿻ Lesbicek
│⿻ Styletext
║⿻ Halah
│⿻ Hilih
║⿻ Huluh
│⿻ Heleh
║⿻ Holoh
│⿻ Jadian
║⿻ Jodohku
│⿻ Delttt
║⿻ Family100
│⿻ Tebak [Option]
║⿻ Math [Mode]
│⿻ Suitpvp [@Tag]
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 PRIMBON MENU 」* ─═⬣
│┏⊱
║⿻ Nomorhoki
│⿻ Artimimpi
║⿻ Artinama
│⿻ Ramaljodoh
║⿻ Ramalcinta
│⿻ Ramaljodohbali
║⿻ Suamiistri
│⿻ Cocoknama
║⿻ Pasangan
│⿻ Jadiannikah
║⿻ Sifatusaha
│⿻ Rezeki
║⿻ Pekerjaan
│⿻ Nasib
║⿻ Penyakit
│⿻ Tarot
║⿻ Fengshui
│⿻ Haribaik
║⿻ Harisangar
│⿻ Harisial
║⿻ Nagahari
│⿻ Arahrezeki
║⿻ Peruntungan
│⿻ Weton
║⿻ Karakter
│⿻ Keberuntungan
║⿻ Masasubur
│⿻ Memancing
║⿻ Zodiak
│⿻ Shio
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 ISLAMIYAH 」* ─═⬣
│┏⊱
║⿻ Iqra
│⿻ Hadist
║⿻ Alquran
│⿻ Juzamma
║⿻ Tafsirsurah
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 BERITA NEWS 」* ─═⬣
│┏⊱
║⿻ Merdeka-News
│⿻ Kontan-News
║⿻ Cnbc-News
│⿻ Tribun-News 
║⿻ Indozone-News 
│⿻ Kompas-News 
║⿻ Detik-News 
│⿻ Daily-News
║⿻ Inews-News 
│⿻ Okezone-News
║⿻ Sindo-News
│⿻ Tempo-News
║⿻ Antara-News
│⿻ Cnn-News 
║⿻ Fajar-News 
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 SCRAPER IMAGE 」* ─═⬣
│┏⊱
║⿻ Anime
│⿻ Coffe
║⿻ Quotesanime
│⿻ Couple
║⿻ Umma
│⿻ Bully
║⿻ Waifu
│⿻ Cuddle
║⿻ Neko
│⿻ Cry
║⿻ Kiss
│⿻ Hug
║⿻ Lick
│⿻ Awoo
║⿻ Yeet
│⿻ Bite
║⿻ Pat
│⿻ Kill
║⿻ Nom
│⿻ Poke
║⿻ Wink
│⿻ Bonk
║⿻ Glomp
│⿻ Smug
║⿻ Blush
│⿻ Wave
║⿻ Smile
│⿻ Highfive
║⿻ Cringe
│⿻ Dance
║⿻ Happy
│⿻ Handhold
║⿻ Darkjoke
│⿻ Meme
║⿻ Meme2
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 SCRAPER IMAGETEXT 」* ─═⬣
│┏⊱
║⿻ Candy
│⿻ Christmas
║⿻ 3Dchristmas
│⿻ Sparklechristmas
║⿻ Deepsea
│⿻ Scifi
║⿻ 3Dbox
│⿻ Drapwater
║⿻ Lion2
│⿻ Papercut
║⿻ 3dstone
│⿻ Thunder
║⿻ Graf
│⿻ Glitch3
║⿻ Transformer
│⿻ Herryp
║⿻ Neondevil
│⿻ 3dstone
║⿻ Rainbow
│⿻ Waterpipe
║⿻ Spooky
│⿻ Pencil
║⿻ Circuit
│⿻ Discovery
║⿻ Metalic
│⿻ Fiction
║⿻ Demon
│⿻ Berry
║⿻ Magma
│⿻ 3Dstone
║⿻ Neonlight
│⿻ Glitch
║⿻ Harrypotter
│⿻ Brokenglass
║⿻ Papercut
│⿻ Watercolor
║⿻ Multicolor
│⿻ Underwater
║⿻ Graffitibike
│⿻ Snow
║⿻ Cloud
│⿻ Honey
║⿻ Ice
│⿻ Fruitjuice
║⿻ Biscuit
│⿻ Wood
║⿻ Chocolate
│⿻ Strawberry
║⿻ Matrix
│⿻ Blood
║⿻ Dropwater
│⿻ Toxic
║⿻ Lava
│⿻ Rock
║⿻ Bloodglas
│⿻ Hallowen
║⿻ Darkgold
│⿻ Joker
║⿻ Wicker
│⿻ Firework
║⿻ Skeleton
│⿻ Blackpink
║⿻ Sand
│⿻ Glue
║⿻ 1917
│⿻ Leaves
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 VOICE CHANGER 」* ─═⬣
│┏⊱
║⿻ Bass
│⿻ Blown
║⿻ Deep
│⿻ Earrape
║⿻ Fast
│⿻ Fat
║⿻ Nightcore
│⿻ Reverse
║⿻ Robot
│⿻ Slow
║⿻ Tupai
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 ASUPAN MATA 」* ─═⬣
│┏⊱
║⿻ Asupan
│⿻ Asupangheayubi
║⿻ Asupanrikagusriani
│⿻ Asupanukhty
║⿻ Asupanbocil
│⿻ Asupansantuy
║⿻ Hijaber
│⿻ Cecanindo
║⿻ Cecanchina
│⿻ Cecanhijaber
║⿻ Cecanmalaysia
│⿻ Cecanthai
║⿻ Cecanvietnam
│⿻ Cecankorea
║⿻ Cecanjepan
│⿻ Bokpig
║⿻ Cecan
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 SEARCH MENU 」* ─═⬣
│┏⊱
║⿻ Play [Query]
│⿻ Yts [Query]
║⿻ Google [Query]
│⿻ Gimage [Query]
║⿻ Pinterest [Query]
│⿻ Wallpaper [Query]
║⿻ Wikimedia [Query]
│⿻ Ytsearch [Query]
║⿻ Ringtone [Query]
│⿻ Searchgroups [Query]
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 SCRAP CONVERT 」* ─═⬣
│┏⊱
║⿻ Attp
│⿻ Ttp
║⿻ Toimage
│⿻ Sticker
║⿻ Emojimix
│⿻ Emojimix2
║⿻ Tovideo
│⿻ Togif
║⿻ Tourl
│⿻ Tovn
║⿻ Toonce
│⿻ Tomp3
║⿻ Toaudio
│⿻ Ebinary
║⿻ Dbinary
│⿻ Styletext
║⿻ Smeme
│⿻ Ssweb [Url]
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 CMD MENU 」* ─═⬣
│┏⊱
║⿻ Setcmd
│⿻ Listcmd
║⿻ Delcmd
│⿻ Lockcmd
║⿻ Addmsg
│⿻ Listmsg
║⿻ Getmsg
│⿻ Delmsg
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 MENU ANONYMOUS 」* ─═⬣
│┏⊱
║⿻ Anonymous
│⿻ Start
║⿻ Next
│⿻ Keluar
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 DOWNLOAD MENU 」* ─═⬣
│┏⊱
║⿻ Pinterestdl [Url]
│⿻ Ytmp3 [Url]
║⿻ Ytmp4 [Url]
│⿻ Tiktok [Url]
║⿻ Tiktokmp3 [Url]
│⿻ Mediafire [Url]
║┗⊱
┗━━━━━━━━━━━━━━━━━━⬣
 
╔─═⊱ *「 RANDOM SOUND 」* ─═⬣
│┏⊱
║⿻ Sound1
│⿻ Sound2
║⿻ Sound3
│⿻ Sound4
║⿻ Sound5
│⿻ Sound6
║⿻ Sound7
│⿻ Sound8
║⿻ Sound9
│⿻ Sound10
║⿻ Sound11
│⿻ Sound12
║⿻ Sound13
│⿻ Sound14
║⿻ Sound15
│⿻ Sound16
║⿻ Sound17
│⿻ Sound18
║⿻ Sound19
│⿻ Sound20
║⿻ Sound21
│⿻ Sound22
║⿻ Sound23
│⿻ Sound24
║⿻ Sound25
│⿻ Sound26
║⿻ Sound27
│⿻ Sound28
║⿻ Sound29
│⿻ Sound30
║⿻ Sound31
│⿻ Sound32
║⿻ Sound33
│⿻ Sound34
║⿻ Sound35
│⿻ Sound36
║⿻ Sound37
│⿻ Sound38
║⿻ Sound39
│⿻ Sound40
║⿻ Sound41
│⿻ Sound42
║⿻ Sound43
│⿻ Sound44
║⿻ Sound45
│⿻ Sound46
║⿻ Sound47
│⿻ Sound48
║⿻ Sound49
│⿻ Sound50
║⿻ Sound51
│⿻ Sound52
║⿻ Sound53
│⿻ Sound54
║⿻ Sound55
│⿻ Sound56
║⿻ Sound57
│⿻ Sound58
║⿻ Sound59
│⿻ Sound60
║⿻ Sound61
│⿻ Sound62
║⿻ Sound63
│⿻ Sound64
║⿻ Sound65
│⿻ Sound66
║⿻ Sound67
│⿻ Sound68
║⿻ Sound69
│⿻ Sound70
║⿻ Sound71
│⿻ Sound72
║⿻ Sound73
│⿻ Sound74
║⿻ Sound75
│⿻ Sound76
║⿻ Sound77
│⿻ Sound78
║⿻ Sound79
│⿻ Sound80
║⿻ Sound81
│⿻ Sound82
║⿻ Sound83
│⿻ Sound84
║⿻ Sound85
│⿻ Sound86
║⿻ Sound87
│⿻ Sound88
║⿻ Sound89
│⿻ Sound90
║⿻ Sound91
│⿻ Sound92
║⿻ Sound93
│⿻ Sound94
║⿻ Sound95
│⿻ Sound96
║⿻ Sound97
│⿻ Sound98
║⿻ Sound99
│⿻ Sound100
║⿻ Sound101
│⿻ Sound102
║⿻ Sound103
│⿻ Sound104
║⿻ Sound105
│⿻ Sound106
║⿻ Sound107
│⿻ Sound108
║⿻ Sound109
│⿻ Sound110
║⿻ Sound111
│⿻ Sound112
║⿻ Sound113
│⿻ Sound114
║⿻ Sound115
│⿻ Sound116
║⿻ Sound117
│⿻ Sound118
║⿻ Sound119
│⿻ Sound120
║⿻ Sound121
│⿻ Sound122
║⿻ Sound123
│⿻ Sound124
║⿻ Sound125
│⿻ Sound126
║⿻ Sound127
│⿻ Sound128
║⿻ Sound129
│⿻ Sound130
║⿻ Sound131
│⿻ Sound132
║⿻ Sound133
│⿻ Sound134
║⿻ Sound135
│⿻ Sound136
║⿻ Sound137
│⿻ Sound138
║⿻ Sound139
│⿻ Sound140
║⿻ Sound141
│⿻ Sound142
║⿻ Sound143
│⿻ Sound144
║⿻ Sound145
│⿻ Sound146
║⿻ Sound147
│⿻ Sound148
║⿻ Sound149
│⿻ Sound150
║⿻ Sound151
│⿻ Sound151
║⿻ Sound153
│⿻ Sound154
║⿻ Sound155
│⿻ Sound156
║⿻ Sound157
│⿻ Sound158
║⿻ Sound159
│⿻ Sound160
║⿻ Sound161
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

╔─═⊱ *「 RPG MENU 」* ─═⬣
│┏⊱
║⿻ Leaderboard
│⿻ Inventori
║⿻ Mining
│⿻ Jual
║⿻ Beli @User
│⿻ Heal
║⿻ Berburu
│┗⊱
┗━━━━━━━━━━━━━━━━━━⬣

┏━━⬣  Thanks To  友
┃ 🔥 The Zyrenn 
┃ 🔥 Hw Mods Wa
┃ 🔥 VannStore
┃ 🔥 The Joo
┃ 🔥 Aztecs
┃ 🔥 Xinn
┗━━⬣  ⿻ Botz Wa ⿻
`
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})